<?php

use App\Models\CurrencyRatio;
use App\Services\Api\CurrencyService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // dd(now()->subDays(7)->toDateTimeString());
    // dd(CurrencyRatio::where('created_at', '>', now()->subDays(7))->get());
    // $pastWeek = today()->subDays(now()->dayOfWeek)->subWeek()->format('Y-m-d');
    // $currencyService = new CurrencyService();
    // $currencyService->getCurrencies();
    // return response(date('Y-m-d H:i', 1632750244));


    return view('welcome');

    // $currencyService = new CurrencyService();
    // $currencyService->ratioCalculation();
});
